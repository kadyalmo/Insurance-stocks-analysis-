clear; clc;
names = {'BUPA','TAWUNIYA','TASI'};
files = {'Project/bupa.xlsx','Project/tawuniya.xlsx','Project/tasi.xlsx'};
for i = 1:3
    t = readtable(files{i});
    t.Date = dateshift(t.Date,'start','day');
    t.Properties.VariableNames{'Close'} = names{i};
    series{i} = table2timetable(t);
end
prices = synchronize(series{:},'intersection');
height(prices)
logRet  = diff(log(prices{:,:}));
returns = array2timetable(logRet,'RowTimes',prices.Date(2:end),'VariableNames',names);
plot(prices.Date, prices{:,:} ./ prices{1,:} * 100)
legend(names); title('Prices rebased to 100'); grid on
save('clean_data.mat','prices','returns','names')
%الهدف من هذي الخطوه هو ترتيب البيانات  وتنظيفها مع رسم الاسهم الثلاثه من ١٠٠ لمقارنة حركتها