clear; clc; close all;
load('clean_data.mat')
R = returns{:,:};

annR = mean(R) * 252;
annV = std(R) * sqrt(252);
covA = cov(R) * 252;
rf   = 0.0617;
beta_all = [covA(1:2,3) ./ covA(3,3); 1];           % بيتا تاسي = 1
capm_all = rf + beta_all .* (annR(3) - rf);         % CAPM لكل الأسهم
VaR95 = prctile(R, 5);                              % VaR يومي لكل سهم


% جدول يجمع نتائج الخطوات من ١-٤
summary = table(names', annR', annV', beta_all, capm_all, VaR95', ...
    'VariableNames', {'Stock','AnnReturn','AnnVol','Beta','CAPM','VaR95_daily'})

% رسوم بيانيه
figure('Position',[100 100 900 700])

subplot(2,2,1)
bar(annR*100); xticklabels(names); title('Annual return (%)'); grid on

subplot(2,2,2)
bar(annV*100); xticklabels(names); title('Annual volatility (%)'); grid on

subplot(2,2,3)
bar(beta_all); xticklabels(names); title('Beta vs TASI'); grid on

subplot(2,2,4)
histogram(R(:,1)*100, 50); hold on
xline(VaR95(1)*100, 'r-', 'VaR 95%', 'LineWidth', 1.5); hold off
title('BUPA daily returns (%)'); grid on

saveas(gcf, 'fig06_summary.png')
