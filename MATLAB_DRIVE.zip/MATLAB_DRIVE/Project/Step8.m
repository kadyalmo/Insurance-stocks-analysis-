% إدارة الأصول والالتزامات (ALM)
clear; clc;

L  = 4748.6;          % الالتزامات (احتياطي المطالبات ٢٠٢٥) بالمليون ريال
DL = 0.5;             % مدة الالتزامات بالسنة (افتراض)
Settle   = '26-Oct-2026';
Maturity = '26-Oct-2029';
Coupon   = 0.05;                 % كوبون ٥٪
Yield    = 0.055;                % العائد السوقي ٥.٥٪
Period   = 2;                    % دفعات نصف سنوية
Basis    = 1;                    % Actual/Actual

Price = bndprice(Yield, Coupon, Settle, Maturity, Period, Basis);
[ModDur, MacDur] = bnddury(Yield, Coupon, Settle, Maturity, Period, Basis);

fprintf('Sample sukuk price (per 100): %.2f\n', Price);
fprintf('Macaulay duration (years)   : %.2f\n', MacDur);
A  = 9568.5;          % إجمالي الاستثمارات (مليون) 
DA = MacDur;          % مدة الأصول (افتراض: محفظة بنفس مدة السند النموذجي)

Dgap = DA - (L/A) * DL;          % فجوة المدة

fprintf('Asset duration : %.2f years\n', DA);
fprintf('Duration gap   : %.2f years\n', Dgap);
dy = [-0.02 -0.01 0.01 0.02];    % تغيرات العائد (-٢٪، -١٪، +١٪، +٢٪)

dAssets   = -DA * A .* dy;       % تغير قيمة الأصول
dLiab     = -DL * L .* dy;       % تغير قيمة الالتزامات
dSurplus  = dAssets - dLiab;     % تغير الفائض

impactTable = table(dy' * 100, dAssets', dLiab', dSurplus', ...
    'VariableNames', {'YieldChange_pct','dAssets_m','dLiabilities_m','dSurplus_m'})
