clear; clc;
load('clean_data.mat')
R = returns{:,:};
annReturn = mean(R) * 252
annVol    = std(R) * sqrt(252)
covMat  = cov(R) * 252
corrMat = corrcoef(R)
beta = covMat(1:2,3) ./ covMat(3,3);
table(names(1:2)', beta, 'VariableNames', {'Stock','Beta'})

rf = 0.0617;                                        % العائد الخالي من المخاطر
beta = covMat(1:2,3) ./ covMat(3,3);                % بيتا لكل سهم مقابل تاسي
Sharpe = (annReturn - rf) ./ annVol                 % نسبة شارب (الثلاث أسهم)
Rm = annReturn(3);                                  % عائد تاسي
alpha = annReturn(1:2) - (rf + beta' .* (Rm - rf))  % ألفا حسب CAPM
