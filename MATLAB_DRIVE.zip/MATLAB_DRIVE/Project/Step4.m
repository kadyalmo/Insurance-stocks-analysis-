% العوائد الشهريه
clear; clc;
load('clean_data.mat')
pM = retime(prices, 'monthly', 'lastvalue');
height(pM)
RM = diff(log(pM{:,:})); 
expM = mean(RM)
varM = var(RM)
covM = cov(RM)

% هذه الخطوه لتأكد من المفترض انها تقارب للعائد السنوي المذكور في الخطوه ٢
resultM = table(names', expM', varM', ...
    'VariableNames', {'Stock','ExpMonthly','VarMonthly'})

annFromMonthly = expM * 12