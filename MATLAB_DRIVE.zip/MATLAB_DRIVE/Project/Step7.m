clear; clc; close all;

C = readcell('Bupa_Claims_Data.xlsx', 'Sheet', 'Data');
years  = [2023 2024 2025];
rev    = cell2mat(C(2,2:4)) / 1000;                             % الإيرادات (مليون ريال)
claims = (cell2mat(C(3,2:4)) + cell2mat(C(4,2:4))) / 1000;      % المطالبات المتكبدة (مليون)
equity = cell2mat(C(10,2:4)) / 1000;                            % حقوق المساهمين (مليون)

LR        = claims ./ rev;                          %  نسبة المطالبات من الخطوه ٦
expRatio  = 0.0235;                                 % مصاريف التشغيل من إيرادات ٢٠٢٥
CR        = LR + expRatio;                          % النسبة المركبة اذا كانت اقل من ١٠٠٪ معناها ربح

summary7 = table(years', rev', claims', LR', CR', equity', ...
    'VariableNames', {'Year','Revenue','Claims','LossRatio','CombinedRatio','Equity'})
% التسعير
avgLR = mean(LR);                                   % متوسط نسبة المطالبات ٣ سنوات
expClaims2026 = avgLR * rev(end);                   % المطالبات المتوقعة لو الحجم بقي مثل ٢٠٢٥
breakEven = expClaims2026 / (1 - expRatio);         % القسط اللي يغطي المطالبات والمصاريف

fprintf('Average loss ratio      : %.1f%%\n', avgLR*100);
fprintf('Break-even premium 2026 : %.0f m SAR\n', breakEven);
fprintf('Actual revenue 2025     : %.0f m SAR\n', rev(end));
% الاحتياطيات
LIC_pv    = (4019149 + 545257) / 1000;              % القيمة الحالية للتدفقات (٢٠٢٥)
RA        = (164366 + 19785) / 1000;                % تعديل المخاطر غير المالية
LIC_total = LIC_pv + RA;

fprintf('LIC PV cash flows : %.1f m (audit KAM: 4,564.4)\n', LIC_pv);
fprintf('Risk adjustment   : %.1f m (audit KAM: 184.2)\n', RA);
fprintf('Total LIC 2025    : %.1f m\n', LIC_total);

rel      = [428512 552239 1162231] / 1000;                        % إفراجات السنوات السابقة
openLIC  = (3847664 + 145494 + 539158 + 16999) / 1000;            % الاحتياطي الافتتاحي ٢٠٢٥
relPct   = rel(3) / openLIC;
fprintf('Releases 2025 = %.1f%% of opening reserves\n', relPct*100);
% احتمال الإفلاس محاكاة ١٠ سنوات
T = 10;                    % عدد السنوات
Nsim = 10000;              % عدد المحاكاة
U0 = equity(end);          % رأس المال الابتدائي = حقوق المساهمين ٢٠٢٥
P  = rev(end);             % القسط السنوي (ثابت)
m  = avgLR * P;            % متوسط المطالبات السنوية
E  = expRatio * P;         % المصاريف السنوية
cvList = [0.05 0.10 0.15]; % تقلب المطالبات (افتراض)

rng(7)
ruinProb = zeros(size(cvList));
for k = 1:numel(cvList)
    sig2 = log(1 + cvList(k)^2);
    sig  = sqrt(sig2);
    mu   = log(m) - sig2/2;
    U = U0 * ones(Nsim,1);
    ruined = false(Nsim,1);
    for t = 1:T
        Ct = exp(mu + sig*randn(Nsim,1));   % مطالبات السنة (لوغ-نورمال)
        U  = U + P - E - Ct;                % الفائض بعد السنة
        ruined = ruined | (U < 0);          % هل نزل تحت الصفر في أي سنة؟
    end
    ruinProb(k) = mean(ruined);
end

ruinTable = table(cvList', ruinProb', ...
    'VariableNames', {'CV_claims','RuinProb_10y'})
