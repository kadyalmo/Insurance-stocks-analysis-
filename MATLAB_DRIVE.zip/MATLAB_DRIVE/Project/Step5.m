clear; clc;
load('clean_data.mat')
pM    = retime(prices, 'monthly', 'lastvalue');
RM    = diff(log(pM{:,:}));
mu    = mean(RM)';
Sigma = cov(RM);
S0    = pM{end,:};        % ناخذ اخر سعر فعلي لكل سهم

% صنع مسارات عشوائيه
N = 5000;                 % عدد المحاكاة
H = 12;                   % عدد الاشهر
rng(1)                    % لتثبيت النتيجه في كل مره يشتغل فيه الكود
P = zeros(H, 3, N);
for k = 1:N
    shocks = mvnrnd(mu', Sigma, H);
    P(:,:,k) = S0 .* exp(cumsum(shocks));
end

% ملخص النتائج بعد ١٢ شهر
final = squeeze(P(H,:,:))';     % سعر كل مسار في آخر شهر

simTable = table(names', S0', mean(final)', ...
    prctile(final,5)', prctile(final,95)', ...
    'VariableNames', {'Stock','LastPrice','MeanPrice12M','P5','P95'})

% رسم عينه من المسارات ل بوبا
figure
plot(squeeze(P(:,1,1:50)))
title('BUPA: 50 simulated price paths')
xlabel('Month'); ylabel('Price (SAR)'); grid on
