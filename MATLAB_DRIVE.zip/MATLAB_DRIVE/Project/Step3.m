clear; clc;
load('clean_data.mat')
R = returns{:,:};

rf   = 0.0617;                    % العائد السنوي الخالي من المخاطر لاستحقاق سنة٢٠٢٦ (%6.17)
annR = mean(R) * 252;                 % العائد السنوي لكل سهم
Rm   = annR(3);                       % عائد السوق (تاسي)
covA = cov(R) * 252;                  % مصفوفة التغاير السنوية
beta = covA(1:2,3) ./ covA(3,3);      % بيتا كل سهم مقابل تاسي

capmReturn = rf + beta .* (Rm - rf);  % معادلة CAPM

capmTable = table(names(1:2)', beta, capmReturn, ...
    'VariableNames', {'Stock','Beta','CAPM_Return'})

%% 4. VaR و CVaR (يومي، ٩٥٪)
VaR95  = zeros(1,3);
CVaR95 = zeros(1,3);
for j = 1:3
    VaR95(j)  = prctile(R(:,j), 5);             % الحد اللي ٥٪ من الايام أسوأ منه
    CVaR95(j) = mean(R(R(:,j) <= VaR95(j), j)); % متوسط الايام اللي أسوأ من الحد
end

riskTable = table(names', VaR95', CVaR95', ...
    'VariableNames', {'Stock','VaR_95','CVaR_95'})